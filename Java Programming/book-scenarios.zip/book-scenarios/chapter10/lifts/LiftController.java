import greenfoot.World;
import greenfoot.Actor;

public class LiftController 
{
    public LiftController()
    {
    }

    public void act()
    {
        // not yet implemented
    }

}